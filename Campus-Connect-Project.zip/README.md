# 🎓 Campus Connect

**Campus Connect** is a professional **Academic Early-Warning System** designed to bridge the gap between data and academic success. Built with a modern "Stitch UI" aesthetic, it provides real-time predictive monitoring to help educators identify at-risk students and improve overall learning outcomes.

---

## 🚀 Key Features

-   **🔍 Predictive Analytics:** Automatically categorizes students (Excellent, Good, At-Risk, Failing) based on real-time academic data.
-   **📊 Dynamic Dashboards:** Specialized views for **Students**, **Teachers**, and **Admins** with interactive charts (Chart.js).
-   **✅ Management Suite:** Effortless attendance tracking and grade management for teachers.
-   **🤖 AI-Style Global Search:** Centralized command bar for quick access to student insights.
-   **📱 Modern UI/UX:** Clean, light-mode interface inspired by modern design systems, featuring glassmorphism and subtle animations.

---

## 🛠️ Tech Stack

-   **Backend:** Node.js, Express.js
-   **Database:** SQLite (Relational schema with triggers and views)
-   **Frontend:** HTML5, Vanilla JavaScript, CSS3 (Custom Design System)
-   **Visualization:** Chart.js

---

## 📂 Project Structure

-   `/frontend`: All client-side assets (HTML, CSS, JS).
-   `server.js`: Express REST API endpoints.
-   `schema.sql`: Database architecture (Tables, Views, Triggers).
-   `init_db.js`: Database initialization script.

---

## 💻 Local Setup

1.  **Clone the Repo:**
    ```bash
    git clone https://github.com/YOUR_USERNAME/campus-connect.git
    cd campus-connect
    ```

2.  **Install Dependencies:**
    ```bash
    npm install
    ```

3.  **Initialize Database:**
    ```bash
    npm run init-db
    ```

4.  **Run the App:**
    ```bash
    npm start
    ```
    Visit `http://localhost:3000` in your browser.

---

## 🔐 Demo Credentials

-   **Admin:** `admin` / `admin123`
-   **Teacher:** `dr_sharma` / `prof123`
-   **Student:** `ananya0` / `student123`

---

## 📄 License
This project is licensed under the MIT License.
